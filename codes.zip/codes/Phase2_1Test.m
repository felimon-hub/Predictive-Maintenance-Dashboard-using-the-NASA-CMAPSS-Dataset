clc
clear vars
close all
%--------Load the data set
engine_Test = readmatrix('PM_test.txt'); 
for it = 1:length(imp_sensor)

sensor_valuesTest(:,it) = engine_Test(:,imp_sensor(it)+5) ;

end
%% 1. CALCULATE GLOBAL TRAINING LIMITS FROM YOUR ENGINE MAX MATRIX
% Strip out the first column (Engine IDs) to keep only the sensor data columns
just_sensor_maxes = max_sensor_matrix(:, 2:end);
global_train_max = max(just_sensor_maxes, [], 1); % 1x11 vector of maximums

% Extract the training minimums matrix to find the baseline healthy floor limits
global_train_min = zeros(1, num_sensors);
for k = 1:num_sensors
    sensor_num = imp_sensor(k);
    col_idx = sensor_num + 5; 
    global_train_min(k) = min(engine_Train(:, col_idx)); % 1x11 vector of minimums
end

%% 2. LEARN THE 11 GLOBAL WEIBULL PARAMETERS (a AND b)
global_a = zeros(num_sensors, 1);
global_b = zeros(num_sensors, 1);
sensor_directions = zeros(num_sensors, 1); % -1 for decreasing, +1 for increasing

train_cycles = engine_Train(:, 2);

fprintf('\n--- Phase 1: Computing 11 Global Weibull Parameters ---\n');
for k = 1:num_sensors
    sensor_num = imp_sensor(k);
    col_idx = sensor_num + 5;
    raw_train_col = engine_Train(:, col_idx);
    
    % Step A: Normalize the training column using our global fleet limits
    g_min = global_train_min(k);
    g_max = global_train_max(k);
    norm_train = (raw_train_col - g_min) / (g_max - g_min);
    
    % Step B: Direction check. Flip (1 - X) if the sensor value falls over time
    % Checked against your pre-computed Correlation_RUL metric
    row_idx = (Results.Sensor == sensor_num);
    r_val = Results.Correlation_RUL(row_idx);
    
    if r_val < 0
        norm_train = 1 - norm_train;
        sensor_directions(k) = -1;
    else
        sensor_directions(k) = 1;
    end
    
    % Step C: Convert to observed empirical Health Index (1 down to 0)
    HI_observed = 1 - norm_train;
    HI_observed = max(0.0001, min(0.9999, HI_observed)); % Numerical boundary guard
    
    % Step D: Transform into Linearized Weibull Log-Log Space
    Y = log(-log(HI_observed));
    X = log(train_cycles);
    
    % Step E: Fit a single global trend line through all combined historical data points
    valid_points = isfinite(X) & isfinite(Y);
    p = polyfit(X(valid_points), Y(valid_points), 1);
    
    global_b(k) = p(1);       % Shape Factor (b) is the line's slope
    global_a(k) = exp(p(2));  % Scale Factor (a) derived from the intercept
    
    fprintf('Sensor %2d Constant Matrix Rules -> a = %11.5e, b = %7.4f\n', ...
            sensor_num, global_a(k), global_b(k));
end
