%% 3. NORMALIZE TEST ENGINES AND COMPUTE LIVE HEALTH SCORE
test_engine_ids = unique(engine_Test(:,1));
num_test_engines = length(test_engine_ids);

Test_Health_Output = [];

for e = 1:num_test_engines
    id = test_engine_ids(e);
    test_idx = (engine_Test(:, 1) == id);
    
    % Extract the timeline cycles for this specific engine run
    engine_cycles = engine_Test(test_idx, 2);
    num_cycles = length(engine_cycles);
    
    for k = 1:num_sensors
        sensor_num = imp_sensor(k);
        raw_test_vector = sensor_valuesTest(test_idx, k);
        
        % Pull parameters learned from the training fleet boundaries
        g_min = global_train_min(k);
        g_max = global_train_max(k);
        s_dir = sensor_directions(k);
        a = global_a(k);
        b = global_b(k);
        
        % Establish a clean running moving average baseline for spike anomaly analysis
        ema_signal = movmean(raw_test_vector, [4 0], 'Endpoints', 'shrink');
        t_min = min(raw_test_vector);
        t_max = max(raw_test_vector);
        signal_span = t_max - t_min;
        
       % --- REPLACE THE INSIDE OF YOUR NESTED 't_idx' LOOP WITH THIS FIX ---
for t_idx = 1:num_cycles
    t = engine_cycles(t_idx);
    current_val = raw_test_vector(t_idx);
    
    % Step A: Global Normalization Scaling (Sensors)
    norm_val = (current_val - g_min) / (g_max - g_min);
    norm_val = max(0, min(1, norm_val)); 
    
    if s_dir == -1
        norm_val = 1 - norm_val; 
    end
    
    % --- THE FIX: STEP B: LIFECYCLE HORIZON NORMALIZATION ---
    % Scale time as a percentage of the total observed path for this engine
    % This prevents early-life timeline divisions from exploding to infinity
    t_horizon = t / num_cycles; 
    
    % Evaluate the hazard envelope based on the lifecycle horizon scale
    hazard_envelope = 1 - exp(-a * (t_horizon^b));
    
    if hazard_envelope > 0
        degradation_ratio = norm_val / hazard_envelope;
        health_score = max(0, min(1, 1 - degradation_ratio));
    else
        % Default to healthy baseline if the hazard timeline hasn't advanced
        health_score = 1.0; 
    end
    
    % Step C: Local Residual Anomaly Flag Engine
    deviation = abs(current_val - ema_signal(t_idx));
    is_anomaly = 0;
    if signal_span > 0 && (deviation / signal_span) > 0.20
        is_anomaly = 1; 
    end
    
    % Save current corrected metrics row
    Test_Health_Output(end+1, :) = [id, t, sensor_num, current_val, health_score, is_anomaly];
end

    end
end

%% 4. EXPORT FLAT DATA FILE MATRIX FOR POWER BI
Test_Health_Summary = array2table(Test_Health_Output, 'VariableNames', ...
    {'EngineID', 'Cycle', 'SensorID', 'RawValue', 'HealthScore', 'IsAnomaly'});

disp(' ');
disp('--- Phase 3 Processed Test Log Verification Sample ---');
disp(head(Test_Health_Summary, 10));

% Direct export to your desktop working environment directory
writetable(Test_Health_Summary, 'PowerBI_Test_Analysis.csv');
fprintf('\nModel Complete! Drag "PowerBI_Test_Analysis.csv" into Power BI to build dashboards.\n');
