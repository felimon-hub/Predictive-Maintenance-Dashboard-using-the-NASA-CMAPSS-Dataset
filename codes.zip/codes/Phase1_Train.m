clc
clear vars
close all
%%------------------load the data----------------
engine_Train = readmatrix('PM_train.txt'); 
engine_ids = unique(engine_Train(:,1));


max_life_matrix = zeros(length(engine_ids),2);

for i = 1:length(engine_ids)

    id = engine_ids(i);

    idx = engine_Train(:,1) == id;

    max_cycle = max(engine_Train(idx,2));

    max_life_matrix(i,:) = [id max_cycle];
RUL(idx) = max_cycle - engine_Train(idx,2);
end



sensor_corr = zeros(21,1);
sensor_values = [engine_Train(:,3),engine_Train(:,4) ,engine_Train(:,8),engine_Train(:,9),engine_Train(:,10),engine_Train(:,11),engine_Train(:,12),engine_Train(:,13),engine_Train(:,14),engine_Train(:,15),engine_Train(:,16),engine_Train(:,17),engine_Train(:,18),engine_Train(:,19),engine_Train(:,20),engine_Train(:,21),engine_Train(:,22),engine_Train(:,23),engine_Train(:,24),engine_Train(:,25),engine_Train(:,26)] ;
for s = 1:21

    

    R = corrcoef(sensor_values(:,s),RUL);

    sensor_corr(s) = R(1,2);
     fprintf('Sensor %2d Correlation = %8.4f\n',...
             s,sensor_corr(s));

end

abs_corr = abs(sensor_corr);
abs_corr(isnan(abs_corr)) = -Inf;


[sorted_corr,idx] = sort(abs_corr,'descend');

for k=1:21

    fprintf('Rank %2d : Sensor %2d Correlation = %.4f\n',...
             k,idx(k),sorted_corr(k));

end
%--------------------
engine_ids = unique(engine_Train(:,1));

num_engines = length(engine_ids);
num_sensors = 21;

mean_slope = zeros(num_sensors,1);
std_slope  = zeros(num_sensors,1);

for s = 1:num_sensors

    slopes = zeros(num_engines,1);

    for e = 1:num_engines

        id = engine_ids(e);

        idx = engine_Train(:,1)==id;

        cycle = engine_Train(idx,2);

        sensor = engine_Train(idx,s+5);

        p = polyfit(cycle,sensor,1);

        slopes(e) = p(1);   % slope

    end

    mean_slope(s) = mean(slopes);
    std_slope(s)  = std(slopes);

end

Sensor = (1:21)';

Results = table( ...
    Sensor,...
    sensor_corr,...
    mean_slope,...
    std_slope,...
    'VariableNames',...
    {'Sensor','Correlation_RUL','MeanSlope','SlopeStd'});
Results.AbsCorr =abs(sensor_corr);
Results.AbsCorr(isnan(Results.AbsCorr)) = -Inf;

Results = sortrows(Results,'AbsCorr','descend');
disp(Results)
for c =1:length(sensor_corr)
    if abs(sensor_corr(c)) >= 0.5
        important_sensor(c) = Sensor(c);
    end
    
end

imp_sensor=find(important_sensor); 

%%

num_engines = length(engine_ids);
num_sensors = length(imp_sensor);

% Pre-allocate matrix: Rows = Engines, Columns = Max Sensor Values
% We add +1 column to store the Engine ID itself in Column 1
max_sensor_matrix = zeros(num_engines, num_sensors + 1);

for i = 1:num_engines
    id = engine_ids(i);
    
    % CRITICAL: Filter data to ONLY look at the current engine ID
    engine_idx = (engine_Train(:, 1) == id);
    
    % Store the Engine ID in the first column
    max_sensor_matrix(i, 1) = id;
    
    for k = 1:num_sensors
        sensor_num = imp_sensor(k);
        col_idx = sensor_num + 5; % Matches your s+5 column shift logic from before
        
        % Calculate the max value strictly for this engine
        max_sensor_matrix(i, k + 1) = max(engine_Train(engine_idx, col_idx));
    end
end
